AI Neirochat website prototype export
Generated: 2026-10-07T15:14:37.580Z
Project: Тип сайта: лендинг. Сделай одну вертикальную продающую страницу с сильным первым экраном, выгодами,

How to open:
1. Unzip the archive.
2. Open index.html in a browser.
3. Keep the folder structure intact when uploading to hosting.

Project structure:
- index.html — home page
- pages/*.html — additional pages
- css/styles.css — shared responsive styles
- js/main.js — tiny client-side enhancements
- data/site.json — editable website structure, pages, sections and theme metadata
- data/project.json — export metadata for developers and automation
- assets/ — folder for images, icons and brand files

Deployment:
- Upload the whole folder to any static hosting.
- The site does not require a backend.
- If you add images manually, put them into assets/ and update paths in HTML/CSS.
